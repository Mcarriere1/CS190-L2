echo "Totally Real Compiler v2.3"
echo "Compiling...."
echo "Adding backdoor"
echo "Hiding backdoor"
echo "Compiling...."
sleep 5
echo "Done"